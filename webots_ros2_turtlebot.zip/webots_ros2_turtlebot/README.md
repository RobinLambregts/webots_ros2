# TurtleBot3 Burger

This package provides a ROS2 interface example for the simulated TurtleBot3 Burger robot in Webots.

Documentation is available [here](https://github.com/cyberbotics/webots_ros2/wiki/Example-TurtleBot3-Burger).
